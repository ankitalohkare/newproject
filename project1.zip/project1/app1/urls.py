from django.urls import path
from .views import studentView,displyView,updateView,deleteView
 
urlpatterns = [
    path('st/',studentView,name='student'),
    path('dv/',displyView,name='display_url'),
    path('up/<int:id>/',updateView,name='updatee'),
    path('dl/<int:id>/',deleteView,name='deletee')
]