from django.db import models

# Create your models here.
class Student(models.Model):
    sid = models.IntegerField(primary_key=True)
    name = models.CharField(max_length=40)
    age = models.IntegerField()
    marks = models.FloatField()
    mail = models.CharField(max_length=40)

def __str__(self):
    return f'{self.sid}---{self.name}--{self.age}--{self.marks}--{self.mail}'
    

    