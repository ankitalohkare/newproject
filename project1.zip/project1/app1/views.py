from django.shortcuts import render,redirect
from .forms import StudentForm
from .models import Student
# Create your views here.

def studentView(request):
    form = StudentForm()
    template_name = 'app1/form.html'
    context = {'form':form}
    if request.method =='POST':
        form = StudentForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('display_url')
    return render(request,template_name,context)

def displyView(request):
    data = Student.objects.all()
    template_name='app1/display.html'
    context ={'data':data}
    return render(request,template_name,context)

def updateView(request,id):
    data = Student.objects.get(sid= id)
    form = StudentForm(instance=data)
    template_name = 'app1/form.html'
    
    if request.method =='POST':
        form = StudentForm(request.POST,instance=data)
        if form.is_valid():
             form.save()
             return redirect('display_url')
    context ={'form':form}
    return render(request,template_name,context)

def deleteView(request,id):
   data = Student.objects.get(sid= id)
   template_name='app1/confo.html'
   context ={'data':data}
   if request.method =='POST':
       data.delete()
       return redirect('display_url')
   return render(request,template_name,context)

